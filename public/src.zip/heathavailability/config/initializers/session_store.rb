# Be sure to restart your server when you modify this file.

Healthavailability::Application.config.session_store :encrypted_cookie_store, key: '_healthavailability_session'
