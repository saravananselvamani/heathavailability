# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!

# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
# You can use `rake secret` to generate a secure secret key.

# Make sure your secret_key_base is kept private
# if you're sharing your code publicly.
Healthavailability::Application.config.secret_key_base = '4a6a6b46808f72e0fca269cfda474524a54e91f7fca8b161a59666dc34373dd42c245698412c65e182467cbd634b31360f63d1364c2a405256e0fb28a20a5a3a'
