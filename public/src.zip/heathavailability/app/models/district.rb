class District < ActiveRecord::Base
end
