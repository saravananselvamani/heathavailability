class Population < ActiveRecord::Base
end
